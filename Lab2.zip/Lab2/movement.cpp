/*
 * movement.cpp
 *
 *  Created on: Feb 7, 2025
 *      Author: jjbaccam
 */

#include <movement.h>

movement::movement()
{
    // TODO Auto-generated constructor stub

}

movement::~movement()
{
    // TODO Auto-generated destructor stub
}

