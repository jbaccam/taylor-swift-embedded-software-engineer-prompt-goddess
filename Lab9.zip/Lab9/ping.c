/**
 * Driver for ping sensor
 * @file ping.c
 * @author
 */

#include "ping.h"
#include "Timer.h"

// Global shared variables
// Use extern declarations in the header file

volatile uint32_t g_start_time = 0;
volatile uint32_t g_end_time = 0;
volatile enum{LOW, HIGH, DONE} g_state = LOW; // State of ping echo pulse

void ping_init (void){

    // enable clock to GPIO port B
    SYSCTL_RCGCGPIO_R |= 0x02;  // enable clock to Port B (bit 1) page 340
//    SYSCTL_RCGCTIMER_R |= 0x08;  // enable clock to bit 3 for timer
    // wait for GPIOB  peripherals to be ready
    while ((SYSCTL_PRGPIO_R & 0x02) == 0) {};
    // enable digital output for pb3
    GPIO_PORTB_DEN_R |= 0x08;  // pb3
    // set pb3 to T3CCP1
    // GPIO_PORTB_PCTL_R |=
    IntRegister(INT_TIMER3B, TIMER3B_Handler);

    IntMasterEnable();

    // Configure and enable the timer
    // TIMER3_CTL_R ???;
}

void ping_trigger (void){
    // So since PB3 will function as a GPIO digital output
    // AND a Timer Input, we'll reconfigure it as a digital output
    // in here so everytime it gets called where it needs
    // to be a digital output, it becomes one
//    g_state = LOW;
    // disable alt function on pb3 for part 1
    GPIO_PORTB_AFSEL_R &= ~0x08;
    // set direction as output for pb3
    GPIO_PORTB_DIR_R |= 0x08;
    // drive pb3 low->high->low
    GPIO_PORTB_DATA_R &= ~0x08;  // ensure low
    GPIO_PORTB_DATA_R |=  0x08;  // drive high
    timer_waitMicros(7);
    GPIO_PORTB_DATA_R &= ~0x08;  // back low
    // re-enable alt function on pb3 for timer
    GPIO_PORTB_AFSEL_R |= 0x08;


    // Disable timer and disable timer interrupt
//    TIMER3_CTL_R ???;
//    TIMER3_IMR_R ???;
//    // Disable alternate function (disconnect timer from port pin)
//    GPIO_PORTB_AFSEL_R ???;
//
//    // YOUR CODE HERE FOR PING TRIGGER/START PULSE
//
//    // Clear an interrupt that may have been erroneously triggered
//    TIMER3_ICR_R ???
//    // Re-enable alternate function, timer interrupt, and timer
//    GPIO_PORTB_AFSEL_R ???;
//    TIMER3_IMR_R ???;
//    TIMER3_CTL_R ???;
}

void TIMER3B_Handler(void){

  // YOUR CODE HERE
  // As needed, go back to review your interrupt handler code for the UART lab.
  // What are the first lines of code in the ISR? Regardless of the device, interrupt handling
  // includes checking the source of the interrupt and clearing the interrupt status bit.
  // Checking the source: test the MIS bit in the MIS register (is the ISR executing
  // because the input capture event happened and interrupts were enabled for that event?
  // Clearing the interrupt: set the ICR bit (so that same event doesn't trigger another interrupt)
  // The rest of the code in the ISR depends on actions needed when the event happens.

}

float ping_getDistance (void){

    // YOUR CODE HERE

}
